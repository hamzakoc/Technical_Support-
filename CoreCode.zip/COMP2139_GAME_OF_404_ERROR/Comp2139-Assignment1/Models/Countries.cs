﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Comp2139_Assignment1.Models
{
    public class Countries
    {
       
        public string CountriesID { get; set; }
        



    }
}